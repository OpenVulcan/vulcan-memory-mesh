// app.go implements the application composition root for the local gRPC runtime.
// app.go 用于实现本地 gRPC 运行时的应用组合根。
package app

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net"
	"os"
	"os/signal"
	"strings"
	"syscall"

	grpcapi "github.com/openvulcan/vmm/internal/adapters/inbound/grpcapi"
	vmmv1 "github.com/openvulcan/vmm/internal/adapters/inbound/grpcapi/proto/v1"
	"github.com/openvulcan/vmm/internal/adapters/outbound/ai_key_failover"
	"github.com/openvulcan/vmm/internal/adapters/outbound/vldb_lancedb"
	"github.com/openvulcan/vmm/internal/adapters/outbound/vldb_postgres"
	"github.com/openvulcan/vmm/internal/adapters/outbound/vldb_sqlite"
	appports "github.com/openvulcan/vmm/internal/app/ports"
	"github.com/openvulcan/vmm/internal/app/usecase"
	"github.com/openvulcan/vmm/internal/config"
	"github.com/openvulcan/vmm/internal/logic/processor"
	"github.com/openvulcan/vmm/internal/platform/logx"
	"github.com/openvulcan/vmm/internal/platform/xid"
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
)

// Application holds the fully wired local runtime, including the gRPC server and shutdown hooks.
// Application 用于持有完整装配后的本地运行时，包括 gRPC 服务和关闭钩子。
type Application struct {
	Config    config.Config
	Logger    *logx.Logger
	Server    *grpc.Server
	Shutdowns []appports.Shutdowner
}

// storageDependencies bundles the relational and vector ports selected for one runtime mode together with the startup schema workflow the composition root must apply.
// storageDependencies 用于打包某个运行模式选中的关系端口、向量端口，以及组合根启动时需要执行的 schema 工作流。
type storageDependencies struct {
	Relational         appports.RelationalStore
	Vector             appports.VectorStore
	ManageVectorSchema bool
}

// NewLocal creates the local application instance.
// NewLocal 用于创建本地应用实例。
func NewLocal(cfg config.Config, prompts appports.PromptSource, layout config.PromptLayout) (*Application, error) {
	return newApplication(cfg, prompts, layout)
}

// newApplication composes the runtime dependencies for the local gRPC server.
// newApplication 用于为本地 gRPC 服务装配运行时依赖。
func newApplication(cfg config.Config, prompts appports.PromptSource, layout config.PromptLayout) (*Application, error) {
	// Initialize shared runtime utilities such as logging and ID generation first.
	// 先初始化日志和 ID 生成器等共享运行时能力。
	logDir, err := resolveRuntimeLogDir(layout)
	if err != nil {
		return nil, err
	}
	fileWriter, err := logx.NewHourlyFileWriter(logDir)
	if err != nil {
		return nil, fmt.Errorf("init runtime log file writer: %w", err)
	}
	// Close eager startup resources again when later dependency wiring fails, so a half-built runtime does not leave file handles behind.
	// 当后续依赖装配失败时，及时关闭这些提前创建的启动资源，避免半装配运行时留下文件句柄。
	initSucceeded := false
	defer func() {
		if initSucceeded {
			return
		}
		_ = fileWriter.Close()
	}()
	logger := logx.New(io.MultiWriter(os.Stdout, fileWriter), logx.Config{
		Level:                cfg.Logging.Level,
		Format:               cfg.Logging.Format,
		DebugPayloads:        cfg.Logging.DebugRPCPayloads,
		ProtectPayloads:      cfg.Logging.ProtectPayloads,
		PayloadEncryptionKey: cfg.Logging.PayloadEncryptionKey,
	})
	ids := xid.NewGenerator()

	// Build outbound dependencies from the active configuration.
	// 根据当前配置构建出站依赖。
	llm, err := buildLLM(cfg)
	if err != nil {
		return nil, err
	}
	embedding, err := buildEmbedding(cfg)
	if err != nil {
		return nil, err
	}
	reranker, err := buildReranker(cfg)
	if err != nil {
		return nil, err
	}
	storageDeps, err := buildStorageDependencies(cfg)
	if err != nil {
		return nil, err
	}
	relational := storageDeps.Relational
	vector := storageDeps.Vector
	noiseCache, ok := relational.(appports.NoiseEmbeddingCache)
	if !ok {
		return nil, fmt.Errorf("relational store does not support noise embedding cache")
	}
	scopeResolver, ok := relational.(appports.RequestScopeResolver)
	if !ok {
		return nil, fmt.Errorf("relational store does not support request scope resolution")
	}
	workspaceStore, ok := relational.(appports.WorkspaceStore)
	if !ok {
		return nil, fmt.Errorf("relational store does not support workspace management")
	}
	schemaVersions, ok := relational.(appports.SchemaVersionStore)
	if !ok {
		return nil, fmt.Errorf("relational store does not support schema version tracking")
	}
	profileStore, ok := relational.(appports.ProfileStore)
	if !ok {
		return nil, fmt.Errorf("relational store does not support profile management")
	}
	memoryStore, ok := relational.(appports.MemoryStore)
	if !ok {
		return nil, fmt.Errorf("relational store does not support unified memory lookup")
	}
	chatCompactStore, ok := relational.(usecase.ChatCompactStore)
	if !ok {
		return nil, fmt.Errorf("relational store does not support session compact updates")
	}
	scratchpadStore, ok := relational.(appports.ScratchpadStore)
	if !ok {
		return nil, fmt.Errorf("relational store does not support scratchpad management")
	}
	scratchpadMaintenanceStore, ok := relational.(appports.ScratchpadMaintenanceStore)
	if !ok {
		return nil, fmt.Errorf("relational store does not support scratchpad maintenance")
	}
	retentionStore, err := usecase.EnsureRetentionStore(relational)
	if err != nil {
		return nil, err
	}
	if storageDeps.ManageVectorSchema {
		if err := ensureVectorSchema(context.Background(), schemaVersions, workspaceStore, vector, logger); err != nil {
			return nil, err
		}
	}
	noiseGate, err := buildNoiseGate(cfg, layout, embedding, noiseCache, logger)
	if err != nil {
		return nil, err
	}

	// Compose use cases on top of processors and outbound ports.
	// 在处理器和出站端口之上装配用例层。
	workspace := usecase.NewWorkspaceUseCase(workspaceStore, vector)
	profiles := usecase.NewProfileUseCase(profileStore, processor.NewManualProfileReviewer(llm, prompts, cfg.LLM.Model), logger)
	memory := usecase.NewMemoryUseCase(profileStore, memoryStore, embedding, vector, logger)
	scratchpad := usecase.NewScratchpadUseCase(scratchpadStore)
	chatCompact := usecase.NewChatCompactUseCase(chatCompactStore)
	candidateReviewer := processor.NewPostActionCandidateReviewer(llm, prompts, cfg.LLM.Model)
	memory.ConfigureHybrid(cfg.MemoryPipeline.HybridEnabled, cfg.MemoryPipeline.LexicalTopK, cfg.MemoryPipeline.RRFK)
	memory.ConfigureMMR(cfg.MemoryPipeline.MMREnabled, cfg.MemoryPipeline.MMRLambda)
	memory.ConfigureDecay(
		cfg.MemoryPipeline.WeibullEnabled,
		cfg.MemoryPipeline.WeibullShape,
		cfg.MemoryPipeline.WeibullScaleHours,
		cfg.MemoryPipeline.WeibullMinMultiplier,
		cfg.MemoryPipeline.WeibullReinforceWeight,
		cfg.MemoryPipeline.WeibullCrossSessionBoost,
	)
	memory.ConfigureRerank(reranker, cfg.Rerank.TopN)
	memory.ConfigureMemoryReplace(candidateReviewer, cfg.PreCheck.TopK, cfg.MemoryReplaceScope, minSimilarityOrDefault(cfg))
	pre := usecase.NewPreCheckUseCase(
		memory,
		relational,
		processor.NewIntentExtractor(llm, prompts, cfg.LLM.Model, cfg.MemoryPipeline.MaxSearchKeywords),
		processor.NewPreCheckMemoryReviewer(llm, prompts, cfg.LLM.Model),
		processor.NewContextAssembler(prompts, cfg.LLM.Model),
		usecase.PreCheckConfig{
			IntentTimeout:      cfg.PreCheck.IntentTimeout.Duration,
			TopK:               cfg.PreCheck.TopK,
			MinSimilarityScore: minSimilarityOrDefault(cfg),
			SearchScope:        cfg.PreCheck.SearchScope,
			HistoryTurns:       cfg.PostAction.SessionAnalysisHistoryTurns,
			MaxInputTokens:     cfg.PostAction.SessionAnalysisMaxInputTokens,
		},
		logger,
	)
	post := usecase.NewPostActionUseCase(
		noiseGate,
		relational,
		embedding,
		vector,
		processor.NewTurnAnalyzer(llm, prompts, cfg.LLM.Model),
		memory,
		candidateReviewer,
		usecase.PostActionAnalysisConfig{
			TurnThreshold:       cfg.PostAction.SessionAnalysisTurnThreshold,
			TokenThreshold:      cfg.PostAction.SessionAnalysisTokenThreshold,
			IdleTimeout:         cfg.PostAction.SessionAnalysisIdleTimeout.Duration,
			HistoryTurns:        cfg.PostAction.SessionAnalysisHistoryTurns,
			MaxInputTokens:      cfg.PostAction.SessionAnalysisMaxInputTokens,
			DedupeSearchTopK:    cfg.PreCheck.TopK,
			MemoryReplaceScope:  cfg.MemoryReplaceScope,
			DedupeMinSimilarity: minSimilarityOrDefault(cfg),
		},
		logger,
	)
	// Retention uses the same shared history-turn knob currently consumed by both PreCheck and PostAction, so the configured hot window is that shared base plus the extra keep turns.
	// 当前运行时里 PreCheck 与 PostAction 共用同一组历史轮数配置，因此 retention 的热窗口等于这组共享基线再加额外保留轮数。
	retentionTurnHotWindowSize := cfg.PostAction.SessionAnalysisHistoryTurns + cfg.Retention.TurnKeepExtraTurns
	retention := usecase.NewRetentionUseCase(retentionStore, vector, usecase.RetentionConfig{
		Enabled:                     cfg.Retention.Enabled,
		RecycleScanInterval:         cfg.Retention.RecycleScanInterval.Duration,
		SessionIdleRecycleAfter:     cfg.Retention.SessionIdleRecycleAfter.Duration,
		TurnHotWindowSize:           retentionTurnHotWindowSize,
		TrashRetention:              cfg.Retention.TrashRetention.Duration,
		ProtectPriorityFloor:        cfg.Retention.ProtectPriorityFloor,
		ProtectMemoryLevelFloor:     cfg.Retention.ProtectMemoryLevelFloor,
		SkipProtectedSharedMemories: cfg.Retention.SkipProtectedSharedMemories,
	}, logger)
	retention.ConfigureScratchpadMaintenanceStore(scratchpadMaintenanceStore)

	// Wire gRPC handlers and shutdown dependencies into the application container.
	// 将 gRPC 处理器和关闭依赖接入应用容器。
	deps := grpcapi.Dependencies{
		IDs:               ids,
		Workspace:         workspace,
		Profiles:          profiles,
		Memory:            memory,
		Scratchpad:        scratchpad,
		ChatCompact:       chatCompact,
		PreCheck:          pre,
		PostAction:        post,
		ScopeResolver:     scopeResolver,
		Logger:            logger,
		Validator:         grpcapi.NewRequestValidator(),
		DebugRPCPayloads:  cfg.Logging.DebugRPCPayloads,
		WorkspaceTimeout:  cfg.GRPC.RequestTimeout.Workspace.Duration,
		PreCheckTimeout:   cfg.GRPC.RequestTimeout.PreCheck.Duration,
		PostActionTimeout: cfg.GRPC.RequestTimeout.PostAction.Duration,
	}
	grpcOptions := []grpc.ServerOption{
		grpc.MaxRecvMsgSize(cfg.GRPC.MaxReceiveMessageBytes),
		grpc.ChainUnaryInterceptor(grpcapi.BuildUnaryInterceptors(deps)...),
	}
	server := grpc.NewServer(grpcOptions...)
	vmmv1.RegisterVMMServiceServer(server, grpcapi.NewServer(deps))
	reflection.Register(server)

	shutdowns := []appports.Shutdowner{fileWriter, relational, vector, post, retention}
	initSucceeded = true
	return &Application{Config: cfg, Logger: logger, Server: server, Shutdowns: shutdowns}, nil
}

// Run starts the gRPC server and coordinates graceful shutdown against context cancellation, OS signals, and serve failures.
// Run 用于启动 gRPC 服务，并在上下文取消、系统信号和服务错误之间协调优雅停机。
func (a *Application) Run(ctx context.Context) error {
	// Fail fast on obviously incomplete runtime state so callers receive one deterministic error instead of a goroutine panic from grpc.Server.
	// 对明显不完整的运行时状态提前失败，让调用方拿到确定性错误，而不是在 goroutine 里被 grpc.Server 触发 panic。
	if a == nil {
		return errors.New("application is nil")
	}
	if ctx == nil {
		ctx = context.Background()
	}
	if a.Server == nil {
		return errors.New("grpc server is not initialized")
	}

	errCh := make(chan error, 1)
	go func() {
		// Bind the TCP listener at start time so TLS can be terminated by an external proxy such as Caddy.
		// 在启动时绑定 TCP 监听器，让 TLS 由外部代理如 Caddy 终止。
		listener, err := net.Listen("tcp", a.Config.GRPC.ListenAddr)
		if err != nil {
			errCh <- err
			return
		}
		a.Logger.Info("grpc server listening", "addr", listener.Addr().String())
		if err := a.Server.Serve(listener); err != nil && !errors.Is(err, grpc.ErrServerStopped) {
			errCh <- err
			return
		}
		errCh <- nil
	}()
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	defer signal.Stop(sigCh)

	select {
	case <-ctx.Done():
		return a.Shutdown(context.Background())
	case sig := <-sigCh:
		a.Logger.Info("received shutdown signal", "signal", sig.String())
		return a.Shutdown(context.Background())
	case err := <-errCh:
		shutdownErr := a.Shutdown(context.Background())
		if err != nil {
			if shutdownErr != nil {
				return errors.Join(err, shutdownErr)
			}
			return err
		}
		return shutdownErr
	}
}

// Shutdown stops the gRPC server and releases downstream resources in reverse construction order.
// Shutdown 用于停止 gRPC 服务，并按构建逆序释放下游资源。
func (a *Application) Shutdown(ctx context.Context) error {
	if a == nil {
		return nil
	}
	if ctx == nil {
		ctx = context.Background()
	}
	timeout := a.Config.GRPC.ShutdownTimeout.Duration
	if timeout <= 0 {
		timeout = config.DefaultLocal().GRPC.ShutdownTimeout.Duration
	}
	shutdownCtx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()

	// Only stop gRPC when the runtime actually finished wiring the server, so partial construction or test doubles can still reuse the shutdown path safely.
	// 只有在运行时确实完成 gRPC 服务装配时才执行停服，这样部分装配对象或测试替身也能安全复用 shutdown 路径。
	if a.Server != nil {
		stopped := make(chan struct{})
		go func() {
			a.Server.GracefulStop()
			close(stopped)
		}()
		select {
		case <-shutdownCtx.Done():
			a.Server.Stop()
		case <-stopped:
		}
	}

	// Continue draining every dependency even if one shutdown step fails, so later resources do not leak simply because an earlier adapter returned an error.
	// 即便某个关闭步骤失败，也继续释放后续依赖，避免前一个适配器报错后导致后面的资源直接泄漏。
	var shutdownErrors []error
	for i := len(a.Shutdowns) - 1; i >= 0; i-- {
		if a.Shutdowns[i] == nil {
			continue
		}
		if err := a.Shutdowns[i].Shutdown(shutdownCtx); err != nil {
			shutdownErrors = append(shutdownErrors, fmt.Errorf("shutdown dependency[%d]: %w", i, err))
		}
	}
	if len(shutdownErrors) > 0 {
		return fmt.Errorf("shutdown completed with dependency errors: %w", errors.Join(shutdownErrors...))
	}
	return nil
}

// minSimilarityOrDefault keeps the pre-check runtime aligned with the validated memory-pipeline similarity floor.
// minSimilarityOrDefault 用于让 pre-check 运行时与已校验过的 memory pipeline 相似度下限保持一致。
func minSimilarityOrDefault(cfg config.Config) float64 {
	if cfg.MemoryPipeline.MinSimilarityScore != nil && *cfg.MemoryPipeline.MinSimilarityScore > 0 {
		return *cfg.MemoryPipeline.MinSimilarityScore
	}
	return 0.75
}

// normalizeProviderAlias keeps runtime adapter selection aligned with config validation by trimming accidental surrounding whitespace before lower-casing provider aliases.
// normalizeProviderAlias 用于在 provider 别名转小写前先裁掉意外的首尾空白，让运行时适配器选择与配置校验保持一致。
func normalizeProviderAlias(provider string) string {
	return strings.ToLower(strings.TrimSpace(provider))
}

// buildLLM selects the configured generation backend used by the debug-stage post-action summary probe and future LLM-driven workflows.
// buildLLM 用于选择当前配置的生成后端，服务调试阶段的 post-action 摘要探测以及未来的 LLM 工作流。
func buildLLM(cfg config.Config) (appports.LLMClient, error) {
	cfg.Normalize()
	switch normalizeProviderAlias(cfg.LLM.Provider) {
	case "openai", "openai_native", "openai_go":
		return ai_key_failover.NewLLMClient(
			cfg.LLM.Endpoint,
			cfg.LLM.Model,
			cfg.LLM.Organization,
			cfg.LLM.Project,
			cfg.LLM.APIKeys,
			cfg.LLM.Params,
			cfg.LLM.ModelParams,
			buildKeyFailoverOptions("llm", cfg.LLM.APIKeys, cfg.LLM.KeyFailover),
		)
	default:
		return nil, fmt.Errorf("unsupported llm provider: %s", cfg.LLM.Provider)
	}
}

// buildEmbedding selects the configured real embedding adapter for recall and semantic filtering.
// buildEmbedding 用于为召回和语义过滤选择当前配置的真实 embedding 适配器。
func buildEmbedding(cfg config.Config) (appports.EmbeddingClient, error) {
	cfg.Normalize()
	switch normalizeProviderAlias(cfg.Embedding.Provider) {
	case "openai", "openai_native", "openai_go":
		return ai_key_failover.NewEmbeddingClient(
			cfg.Embedding.Endpoint,
			cfg.Embedding.Model,
			cfg.Embedding.Dimension,
			cfg.Embedding.Organization,
			cfg.Embedding.Project,
			cfg.Embedding.APIKeys,
			cfg.Embedding.Params,
			cfg.Embedding.ModelParams,
			buildKeyFailoverOptions("embedding", cfg.Embedding.APIKeys, cfg.Embedding.KeyFailover),
		)
	default:
		return nil, fmt.Errorf("unsupported embedding provider: %s", cfg.Embedding.Provider)
	}
}

// buildReranker selects the optional second-stage rerank backend used to reorder first-stage vector recall hits.
// buildReranker 用于选择可选的第二阶段重排序后端，对首轮向量召回结果重新排序。
func buildReranker(cfg config.Config) (appports.RerankerClient, error) {
	cfg.Normalize()
	if !cfg.Rerank.Enabled {
		return nil, nil
	}
	switch normalizeProviderAlias(cfg.Rerank.Provider) {
	case "dashscope":
		return ai_key_failover.NewRerankerClient(
			cfg.Rerank.Endpoint,
			cfg.Rerank.Model,
			cfg.Rerank.Timeout.Duration,
			cfg.Rerank.APIKeys,
			buildKeyFailoverOptions("rerank", cfg.Rerank.APIKeys, cfg.Rerank.KeyFailover),
		)
	default:
		return nil, fmt.Errorf("unsupported rerank provider: %s", cfg.Rerank.Provider)
	}
}

// buildKeyFailoverOptions converts one normalized runtime config into the fixed-model API-key failover options consumed by outbound wrappers.
// buildKeyFailoverOptions 用于把一份已归一化的运行时配置转换为出站包装器消费的固定模型 API Key 容灾参数。
func buildKeyFailoverOptions(serviceName string, apiKeys []string, cfg config.KeyFailoverConfig) ai_key_failover.Options {
	return ai_key_failover.Options{
		ServiceName:        serviceName,
		Enabled:            cfg.Enabled && len(apiKeys) > 1,
		Policy:             strings.TrimSpace(cfg.Policy),
		APIKeys:            append([]string(nil), apiKeys...),
		RespectRetryAfter:  cfg.RespectRetryAfter,
		RateLimitCooldown:  cfg.RateLimitCooldown.Duration,
		QuotaCooldown:      cfg.QuotaCooldown.Duration,
		AuthCooldown:       cfg.AuthCooldown.Duration,
		ProbeAfterCooldown: cfg.ProbeAfterCooldown,
	}
}

// buildStorageDependencies selects either the historical split stores or the unified PostgreSQL combined store and returns the matching runtime ports.
// buildStorageDependencies 用于选择历史分离存储或统一 PostgreSQL 组合库，并返回对应的运行时端口集合。
func buildStorageDependencies(cfg config.Config) (storageDependencies, error) {
	if cfg.UsesCombinedPostgres() {
		combined, err := buildCombinedStore(cfg)
		if err != nil {
			return storageDependencies{}, err
		}
		return storageDependencies{
			Relational:         combined,
			Vector:             combined,
			ManageVectorSchema: false,
		}, nil
	}
	relational, err := buildRelational(cfg)
	if err != nil {
		return storageDependencies{}, err
	}
	vector, err := buildVector(cfg)
	if err != nil {
		return storageDependencies{}, err
	}
	return storageDependencies{
		Relational:         relational,
		Vector:             vector,
		ManageVectorSchema: true,
	}, nil
}

// buildCombinedStore selects the unified PostgreSQL-backed combined store used by the new dialect pattern runtime.
// buildCombinedStore 用于选择 Dialect Pattern 运行时使用的统一 PostgreSQL 组合库。
func buildCombinedStore(cfg config.Config) (*vldb_postgres.Store, error) {
	if !cfg.UsesCombinedPostgres() {
		return nil, fmt.Errorf("combined postgres store is disabled for storage.mode=%s", cfg.StorageMode())
	}
	return vldb_postgres.NewStore(vldb_postgres.Config{
		DSN:                     cfg.Postgres.DSN,
		Schema:                  cfg.Postgres.Schema,
		Flavor:                  cfg.Postgres.Flavor,
		QueryTimeout:            cfg.Postgres.QueryTimeout.Duration,
		ConnectTimeout:          cfg.Postgres.ConnectTimeout.Duration,
		MaxOpenConns:            cfg.Postgres.MaxOpenConns,
		MinIdleConns:            cfg.Postgres.MinIdleConns,
		AutoCreateExtensions:    cfg.Postgres.AutoCreateExtensions,
		BM25IndexConcurrently:   cfg.Postgres.BM25IndexConcurrently,
		BM25IndexName:           cfg.Postgres.BM25IndexName,
		TRGMSimilarityThreshold: cfg.Postgres.TRGMSimilarityThreshold,
		VectorLists:             cfg.Postgres.VectorLists,
		VectorProbes:            cfg.Postgres.VectorProbes,
		MigrationBatchSize:      cfg.Postgres.MigrationBatchSize,
		EmbeddingDimension:      cfg.Embedding.Dimension,
	})
}

// buildVector selects the configured vector backend used by retrieval and destructive cleanup flows.
// buildVector 用于选择当前配置的向量后端，服务检索和破坏性清理流程。
func buildVector(cfg config.Config) (appports.VectorStore, error) {
	switch normalizeProviderAlias(cfg.Vector.Provider) {
	case "lancedb":
		return vldb_lancedb.NewStore(cfg.LanceDB.Address, cfg.LanceDB.Timeout.Duration, cfg.LanceDB.TableName, cfg.LanceDB.VectorColumn, cfg.Embedding.Dimension)
	default:
		return nil, fmt.Errorf("unsupported vector provider: %s", cfg.Vector.Provider)
	}
}

// buildRelational selects the configured durable SQL backend used by workspace/session/turn persistence.
// buildRelational 用于选择当前配置的长期 SQL 后端，服务层级、session 和 turn 持久化。
func buildRelational(cfg config.Config) (appports.RelationalStore, error) {
	switch normalizeProviderAlias(cfg.Relational.Provider) {
	case "sqlite":
		return vldb_sqlite.NewStore(cfg.SQLite.Address, cfg.SQLite.Timeout.Duration, vldb_sqlite.StoreOptions{
			LexicalPreTokenize: cfg.MemoryPipeline.LexicalPreTokenize,
		})
	default:
		return nil, fmt.Errorf("unsupported relational provider: %s", cfg.Relational.Provider)
	}
}

// buildNoiseGate builds the pre-persistence admission gate that blocks noisy single-round turns from entering long-term memory.
// buildNoiseGate 用于构建写库前的准入门控器，阻止噪声单轮问答进入长期记忆。
func buildNoiseGate(cfg config.Config, layout config.PromptLayout, embedding appports.EmbeddingClient, cache appports.NoiseEmbeddingCache, logger *logx.Logger) (*processor.NoiseGate, error) {
	return processor.NewNoiseGate(context.Background(), embedding, logger, processor.NoiseGateConfig{
		SystemDir:         layout.SystemNoiseRulesDir(),
		UserDir:           layout.UserNoiseRulesDir(),
		DefaultLanguage:   cfg.Noise.DefaultLanguage,
		Enabled:           cfg.Noise.Enabled,
		SemanticEnabled:   cfg.Noise.SemanticEnabled,
		SemanticThreshold: cfg.Noise.SemanticThreshold,
		Model:             cfg.Embedding.Model,
		Dimension:         cfg.Embedding.Dimension,
		Cache:             cache,
	})
}
